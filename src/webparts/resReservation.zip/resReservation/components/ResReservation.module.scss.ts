/* tslint:disable */
require("./ResReservation.module.css");
const styles = {
  resReservation: 'resReservation_f88c591b',
  container: 'container_f88c591b',
  width: 'width_f88c591b',
  venueSearch: 'venueSearch_f88c591b',
  searchContainer: 'searchContainer_f88c591b',
  searchResults: 'searchResults_f88c591b',
  previewChip: 'previewChip_f88c591b',
  closeBtn: 'closeBtn_f88c591b',
  formHandle: 'formHandle_f88c591b',
  paper: 'paper_f88c591b',
  helpTextClasses: 'helpTextClasses_f88c591b',
  dropZone: 'dropZone_f88c591b',
  data: 'data_f88c591b',
  image: 'image_f88c591b',
  facilityDetails: 'facilityDetails_f88c591b',
  error: 'error_f88c591b',
  label: 'label_f88c591b',
  button: 'button_f88c591b'
};

export default styles;
/* tslint:enable */