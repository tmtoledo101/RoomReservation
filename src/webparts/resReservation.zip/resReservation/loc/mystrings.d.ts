declare interface IResReservationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ResReservationWebPartStrings' {
  const strings: IResReservationWebPartStrings;
  export = strings;
}
